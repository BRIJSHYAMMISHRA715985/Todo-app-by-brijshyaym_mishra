module.exports = {
  mongoURI: 'mongodb://localhost/tododb-dev'
}
